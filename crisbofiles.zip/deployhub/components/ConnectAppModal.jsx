"use client";

import { useEffect, useState } from "react";
import { X, Github, Search, ChevronRight, ChevronLeft } from "lucide-react";
import { upsertApp, newAppId, getVercelCreds, saveVercelCreds } from "@/lib/appsStore";

const EMOJIS = ["▲", "🚀", "🎨", "🛒", "📦", "🐙", "🔥", "🌐", "💼", "🎯"];

export default function ConnectAppModal({ onClose, onSaved }) {
  const [step, setStep] = useState(1);
  const [repos, setRepos] = useState([]);
  const [loadingRepos, setLoadingRepos] = useState(true);
  const [search, setSearch] = useState("");
  const [selectedRepo, setSelectedRepo] = useState(null);

  const [name, setName] = useState("");
  const [emoji, setEmoji] = useState(EMOJIS[0]);
  const [hosting, setHosting] = useState("none"); // none | vercel | hostinger

  const [vercelToken, setVercelToken] = useState("");
  const [vercelTeamId, setVercelTeamId] = useState("");
  const [vercelProjects, setVercelProjects] = useState([]);
  const [vercelProjectId, setVercelProjectId] = useState("");
  const [deployHookUrl, setDeployHookUrl] = useState("");
  const [loadingVercel, setLoadingVercel] = useState(false);

  const [ftp, setFtp] = useState({
    protocol: "ftp",
    host: "",
    port: "",
    username: "",
    password: "",
    remotePath: "/public_html",
  });

  useEffect(() => {
    const creds = getVercelCreds();
    if (creds) {
      setVercelToken(creds.token || "");
      setVercelTeamId(creds.teamId || "");
    }
    fetch("/api/repos")
      .then((r) => r.json())
      .then((data) => setRepos(data.repos || []))
      .finally(() => setLoadingRepos(false));
  }, []);

  const filteredRepos = repos.filter((r) =>
    r.fullName.toLowerCase().includes(search.toLowerCase())
  );

  const loadVercelProjects = async () => {
    if (!vercelToken) return;
    setLoadingVercel(true);
    saveVercelCreds({ token: vercelToken, teamId: vercelTeamId });
    try {
      const q = new URLSearchParams({ token: vercelToken, ...(vercelTeamId ? { teamId: vercelTeamId } : {}) });
      const res = await fetch(`/api/vercel/projects?${q}`);
      const data = await res.json();
      setVercelProjects(data.projects || []);
    } finally {
      setLoadingVercel(false);
    }
  };

  const handleSave = () => {
    const app = {
      id: newAppId(),
      name: name || selectedRepo.name,
      emoji,
      framework: null,
      github: {
        owner: selectedRepo.owner,
        repo: selectedRepo.name,
        defaultBranch: selectedRepo.defaultBranch,
      },
      vercel:
        hosting === "vercel"
          ? {
              enabled: true,
              projectId: vercelProjectId,
              token: vercelToken,
              teamId: vercelTeamId || undefined,
              deployHookUrl: deployHookUrl || undefined,
            }
          : { enabled: false },
      hostinger: hosting === "hostinger" ? { enabled: true, ...ftp, port: ftp.port ? Number(ftp.port) : undefined } : { enabled: false },
    };
    upsertApp(app);
    onSaved(app);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
      <div className="bg-panel border border-border rounded-xl2 w-full max-w-lg max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <h2 className="font-semibold text-[15px]">Conectar aplicación</h2>
          <button onClick={onClose} className="text-muted hover:text-white">
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto scrollbar-thin px-5 py-5">
          {step === 1 && (
            <div>
              <p className="text-[12.5px] text-muted mb-3">Elige el repositorio de GitHub para esta app</p>
              <div className="relative mb-3">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Buscar repositorio..."
                  className="w-full bg-panel2 border border-border rounded-lg pl-8 pr-3 py-2.5 text-[13px] outline-none focus:border-accent"
                />
              </div>
              {loadingRepos ? (
                <p className="text-[12.5px] text-muted py-6 text-center">Cargando repositorios...</p>
              ) : (
                <div className="flex flex-col gap-1.5 max-h-72 overflow-y-auto scrollbar-thin">
                  {filteredRepos.map((r) => (
                    <button
                      key={r.id}
                      onClick={() => {
                        setSelectedRepo(r);
                        setName(r.name);
                      }}
                      className={`text-left flex items-center gap-2.5 px-3 py-2.5 rounded-lg border text-[13px] transition-colors ${
                        selectedRepo?.id === r.id
                          ? "border-accent bg-accent-soft"
                          : "border-transparent bg-panel2 hover:border-border"
                      }`}
                    >
                      <Github size={14} className="text-muted flex-shrink-0" />
                      <span className="truncate">{r.fullName}</span>
                      {r.private && (
                        <span className="ml-auto text-[10px] text-muted border border-border rounded px-1.5 py-0.5">
                          privado
                        </span>
                      )}
                    </button>
                  ))}
                  {filteredRepos.length === 0 && (
                    <p className="text-[12.5px] text-muted py-6 text-center">Sin resultados</p>
                  )}
                </div>
              )}
            </div>
          )}

          {step === 2 && (
            <div>
              <p className="text-[12.5px] text-muted mb-4">Personaliza cómo se ve esta app en tu dashboard</p>
              <label className="block text-[11px] uppercase tracking-wide text-muted mb-1.5">Nombre</label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-panel2 border border-border rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-accent mb-4"
              />
              <label className="block text-[11px] uppercase tracking-wide text-muted mb-1.5">Ícono</label>
              <div className="flex gap-2 flex-wrap">
                {EMOJIS.map((e) => (
                  <button
                    key={e}
                    onClick={() => setEmoji(e)}
                    className={`w-9 h-9 rounded-lg border flex items-center justify-center text-base ${
                      emoji === e ? "border-accent bg-accent-soft" : "border-border bg-panel2"
                    }`}
                  >
                    {e}
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 3 && (
            <div>
              <p className="text-[12.5px] text-muted mb-4">
                ¿Dónde vive esta app en producción? (opcional, puedes agregarlo después)
              </p>
              <div className="flex gap-2 mb-5">
                {[
                  { key: "none", label: "Solo GitHub" },
                  { key: "vercel", label: "Vercel" },
                  { key: "hostinger", label: "Hostinger" },
                ].map((o) => (
                  <button
                    key={o.key}
                    onClick={() => setHosting(o.key)}
                    className={`flex-1 text-[12.5px] font-medium py-2.5 rounded-lg border ${
                      hosting === o.key ? "border-accent bg-accent-soft text-accent" : "border-border bg-panel2 text-muted"
                    }`}
                  >
                    {o.label}
                  </button>
                ))}
              </div>

              {hosting === "vercel" && (
                <div className="flex flex-col gap-3">
                  <div>
                    <label className="block text-[11px] uppercase tracking-wide text-muted mb-1.5">
                      Token de Vercel
                    </label>
                    <input
                      type="password"
                      value={vercelToken}
                      onChange={(e) => setVercelToken(e.target.value)}
                      placeholder="Account Settings → Tokens"
                      className="w-full bg-panel2 border border-border rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-accent"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] uppercase tracking-wide text-muted mb-1.5">
                      Team ID (opcional)
                    </label>
                    <input
                      value={vercelTeamId}
                      onChange={(e) => setVercelTeamId(e.target.value)}
                      className="w-full bg-panel2 border border-border rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-accent"
                    />
                  </div>
                  <button
                    onClick={loadVercelProjects}
                    className="text-[12.5px] text-accent self-start"
                    disabled={!vercelToken || loadingVercel}
                  >
                    {loadingVercel ? "Buscando proyectos..." : "Buscar proyectos de Vercel →"}
                  </button>
                  {vercelProjects.length > 0 && (
                    <div>
                      <label className="block text-[11px] uppercase tracking-wide text-muted mb-1.5">Proyecto</label>
                      <select
                        value={vercelProjectId}
                        onChange={(e) => setVercelProjectId(e.target.value)}
                        className="w-full bg-panel2 border border-border rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-accent"
                      >
                        <option value="">Selecciona...</option>
                        {vercelProjects.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                  <div>
                    <label className="block text-[11px] uppercase tracking-wide text-muted mb-1.5">
                      Deploy Hook URL <span className="normal-case text-muted">(opcional)</span>
                    </label>
                    <input
                      value={deployHookUrl}
                      onChange={(e) => setDeployHookUrl(e.target.value)}
                      placeholder="Project Settings → Git → Deploy Hooks"
                      className="w-full bg-panel2 border border-border rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-accent"
                    />
                  </div>
                </div>
              )}

              {hosting === "hostinger" && (
                <div className="flex flex-col gap-3">
                  <select
                    value={ftp.protocol}
                    onChange={(e) => setFtp({ ...ftp, protocol: e.target.value })}
                    className="w-full bg-panel2 border border-border rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-accent"
                  >
                    <option value="ftp">FTP</option>
                    <option value="ftps">FTPS</option>
                    <option value="sftp">SFTP</option>
                  </select>
                  <div className="flex gap-2">
                    <input
                      value={ftp.host}
                      onChange={(e) => setFtp({ ...ftp, host: e.target.value })}
                      placeholder="ftp.tudominio.com"
                      className="flex-[3] bg-panel2 border border-border rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-accent"
                    />
                    <input
                      value={ftp.port}
                      onChange={(e) => setFtp({ ...ftp, port: e.target.value })}
                      placeholder="21"
                      className="flex-1 bg-panel2 border border-border rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-accent"
                    />
                  </div>
                  <input
                    value={ftp.username}
                    onChange={(e) => setFtp({ ...ftp, username: e.target.value })}
                    placeholder="Usuario"
                    className="w-full bg-panel2 border border-border rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-accent"
                  />
                  <input
                    type="password"
                    value={ftp.password}
                    onChange={(e) => setFtp({ ...ftp, password: e.target.value })}
                    placeholder="Contraseña"
                    className="w-full bg-panel2 border border-border rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-accent"
                  />
                  <input
                    value={ftp.remotePath}
                    onChange={(e) => setFtp({ ...ftp, remotePath: e.target.value })}
                    placeholder="/public_html"
                    className="w-full bg-panel2 border border-border rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-accent"
                  />
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between px-5 py-4 border-t border-border">
          <button
            onClick={() => setStep((s) => Math.max(1, s - 1))}
            disabled={step === 1}
            className="text-[12.5px] text-muted disabled:opacity-30 flex items-center gap-1"
          >
            <ChevronLeft size={14} /> Atrás
          </button>

          {step < 3 ? (
            <button
              onClick={() => setStep((s) => s + 1)}
              disabled={step === 1 && !selectedRepo}
              className="bg-accent text-white text-[13px] font-medium px-4 py-2 rounded-lg disabled:opacity-40 flex items-center gap-1"
            >
              Siguiente <ChevronRight size={14} />
            </button>
          ) : (
            <button
              onClick={handleSave}
              className="bg-accent text-white text-[13px] font-medium px-4 py-2 rounded-lg"
            >
              Guardar aplicación
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
