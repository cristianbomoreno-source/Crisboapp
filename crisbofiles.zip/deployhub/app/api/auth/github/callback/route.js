import { NextResponse } from "next/server";
import { exchangeCodeForToken, getViewer } from "@/lib/github";
import { setSession } from "@/lib/session";

export async function GET(req) {
  const { searchParams, origin } = req.nextUrl;
  const code = searchParams.get("code");
  const state = searchParams.get("state");
  const savedState = req.cookies.get("crisbofiles_oauth_state")?.value;

  if (!code || !state || state !== savedState) {
    return NextResponse.redirect(`${origin}/login?error=state_mismatch`);
  }

  try {
    const redirectUri = `${origin}/api/auth/github/callback`;
    const token = await exchangeCodeForToken(code, redirectUri);
    const viewer = await getViewer(token);

    const res = NextResponse.redirect(`${origin}/dashboard`);
    setSession(res, {
      token,
      login: viewer.login,
      name: viewer.name,
      avatarUrl: viewer.avatar_url,
    });
    res.cookies.set("crisbofiles_oauth_state", "", { path: "/", maxAge: 0 });
    return res;
  } catch (err) {
    return NextResponse.redirect(`${origin}/login?error=${encodeURIComponent(err.message)}`);
  }
}
