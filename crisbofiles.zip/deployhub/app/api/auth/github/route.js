import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { getAuthorizeUrl } from "@/lib/github";

export async function GET(req) {
  const origin = req.nextUrl.origin;
  const redirectUri = `${origin}/api/auth/github/callback`;
  const state = randomUUID();

  const res = NextResponse.redirect(getAuthorizeUrl(redirectUri, state));
  res.cookies.set("crisbofiles_oauth_state", state, {
    httpOnly: true,
    secure: true,
    sameSite: "lax",
    path: "/",
    maxAge: 600,
  });
  return res;
}
